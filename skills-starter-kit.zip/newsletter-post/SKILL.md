---
name: newsletter-post
description: Use when writing the weekly AI with Pelumi newsletter, a guide for aiwithpelumi.com, or any long-form teardown post.
---

# Skill: Newsletter Post (the teardown)

**Use when:** writing the weekly AI with Pelumi newsletter. It publishes at aiwithpelumi.com/posts/, not on Substack.
**Load first:** your own voice, audience and business files, if you keep them. If you don't yet, that's the next thing to write.

---

## The format: a teardown, not a tutorial

Every guide takes one real thing I built and pulls it apart. The reader should be able to copy the method by the end.

**The promise of every guide:** *I show the build, or I don't post.*

---

## The structure

**1. Title: a specific, surprising claim.**
Not a topic. A claim.
> "A UI/UX designer needed a website built. He called a marketer."

**2. Subtitle: the outcome plus the promise of the method.**
Italicised, one line.
> *"I shipped a full landing page for an agri-investment platform in a few hours, with AI doing the building and me doing the thinking. Here's exactly how."*

**3. The setup.** Two or three short paragraphs. What happened, who was involved, why it's notable. Land the punchline of the situation early. Don't build to it.

**4. "What actually got built."** A concrete inventory. Sections, features, the invisible plumbing most people skip (metadata, sitemaps, structured data). Name the stack. This is the proof section. No adjectives, just contents.

**5. "The part nobody believes."** The counterintuitive core of the method. Usually: I didn't write any code, and here's what I typed instead.

**6. The method, step by step.** This is the meat. Be precise about what I actually did: the brief, the plan, the references, the prompts. Show the wiring. If a reader can't reproduce it, the section failed.

**7. What broke.** Mandatory. Every guide names at least one thing that went wrong and how it got diagnosed. This is what separates this newsletter from the hype accounts.

**8. What AI still couldn't do.** Also mandatory. The honest ceiling. Judgment calls, real testimonials, my own headshot, choosing a vendor.

**9. The takeaway.** One paragraph. What the reader should do differently on Monday.

---

## Rules

- **First person, always.** Short lines. Uneven pacing.
- **Specifics over claims.** "Ten sections, ten legal pages, two evenings" beats "a big project."
- **Name real tools and real numbers.** Never round up to sound impressive.
- **Never fake social proof or invent results.**
- **Ladder to a pillar.** Every guide should sit under one of your content pillars. Mine are Content Engine, Build It Don't Learn It, Your AI Workforce, and Prompt to Production. Replace those with yours. If a piece doesn't fit one, question whether it should exist.
- Run the final draft through the `stop-slop` skill before publishing.

---

## Never

- Never a "5 tools you need" listicle. That's not the brand.
- Never a trend recap or a news reaction.
- Never publish a guide where nothing was actually built.
