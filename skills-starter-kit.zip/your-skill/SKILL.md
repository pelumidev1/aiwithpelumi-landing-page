---
name: [short-name-with-dashes]
description: Use when [the exact words you type when you want this].
---

# [What this is]

## Use this when
[The situations. Be specific. Name the surfaces: posts, emails, decks, whatever they are.]

## Steps
1. [First thing, plainly]
2. [Second thing]
3. [Third thing]

## Rules
- [A hard rule, not a preference]
- [Another one]

## Never
- [The thing that makes you wince]
- [The other thing]

## What good looks like
[Paste one real example of your own work. This section does more than all the rest combined.]
