# Two skills to start with

Two folders. Each holds one `SKILL.md`.

`newsletter-post/` is the real file I use to write my newsletter, lightly edited so the
parts that only make sense inside my own setup are marked for you to replace. It is here
as a worked example rather than something to use as is.

`your-skill/` is empty scaffolding. This is the one you fill in.

## What a skill is

A folder with a `SKILL.md` inside it. The file tells the model how you want one specific
job done: your steps, your rules, your examples.

At startup the model reads only two lines from each skill, the name and the description.
It opens the rest when something you ask matches that description.

Which means the description is a trigger, not a summary. Write down the words you
actually type when you want this job done, not what the file is about.

"Brand voice guidelines" never fires. "Use when writing posts, emails, or landing page
copy" fires on its own.

## Where to put it

**Claude Code**
Save the folder at `.claude/skills/your-skill/SKILL.md` in your project, or at
`~/.claude/skills/` to have it everywhere. It loads on its own.

**Claude**
Settings, then Capabilities. Turn on code execution, then Skills. Your own skills upload
as a zipped folder.

**ChatGPT**
Business, Enterprise, Edu and Healthcare plans. Create one in the sidebar or upload a
folder. Type @ then the skill name to call it directly. On Free, Plus and Pro there is no
Skills feature yet, so put the same text into a Project's instructions instead.

**Cursor, Copilot, VS Code, Gemini CLI**
Drop the folder in. They read the same open format.

## How to actually build one

1. Find the paragraph you have retyped three times. Not your most impressive workflow,
   your most repeated one.
2. Write it like an SOP for a new hire, not a prompt for a machine. Boring on purpose.
3. Spend most of your effort on the description line.
4. Fill it with your nevers, not just your wants. Ban words by name.
5. Put one real example of your own work in it.
6. Edit the file the moment it gets something wrong. A prompt you fix stays fixed for one
   conversation. A skill you fix stays fixed forever.

One skill, one job. Four small files beat one file that tries to do four things.

---

Built by Pelumi Fatoye. aiwithpelumi.com
